(function () {
  "use strict";

  var STORAGE_KEY = "quranLowerThirdState";
  var CHANNEL_NAME = "quran-lower-third";

  var defaultState = {
    name: "",
    category: "12 އަހަރުން ދަށް",
    visible: false,
    updatedAt: Date.now(),
  };

  function safeReadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return Object.assign({}, defaultState);
      }

      var parsed = JSON.parse(raw);
      return {
        name: typeof parsed.name === "string" ? parsed.name : defaultState.name,
        category: typeof parsed.category === "string" ? parsed.category : defaultState.category,
        visible: Boolean(parsed.visible),
        updatedAt: typeof parsed.updatedAt === "number" ? parsed.updatedAt : Date.now(),
      };
    } catch (error) {
      return Object.assign({}, defaultState);
    }
  }

  function safeWriteState(state) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      // In strict file-origin policies, storage can fail; channel still attempts sync.
    }
  }

  function createChannel() {
    try {
      if ("BroadcastChannel" in window) {
        return new BroadcastChannel(CHANNEL_NAME);
      }
    } catch (error) {
      return null;
    }
    return null;
  }

  var channel = createChannel();

  function publishState(state) {
    safeWriteState(state);
    if (channel) {
      channel.postMessage(state);
    }
  }

  function initControlPage() {
    var nameInput = document.getElementById("nameInput");
    var categorySelect = document.getElementById("categorySelect");
    var showButton = document.getElementById("showButton");
    var hideButton = document.getElementById("hideButton");
    var statusText = document.getElementById("statusText");

    if (!nameInput || !categorySelect || !showButton || !hideButton || !statusText) {
      return;
    }

    var currentState = safeReadState();
    nameInput.value = currentState.name;
    categorySelect.value = currentState.category;
    refreshStatus(currentState.visible);

    function refreshStatus(isVisible) {
      statusText.textContent = isVisible ? "ހާލަތް: ސަކްރީންގައި ފެނޭ" : "ހާލަތް: ސަކްރީންގައި ނުފެނޭ";
    }

    function buildState(visibleValue) {
      return {
        name: nameInput.value.trim(),
        category: categorySelect.value,
        visible: visibleValue,
        updatedAt: Date.now(),
      };
    }

    function syncWhileVisible() {
      var nextState = buildState(currentState.visible);
      currentState = nextState;
      publishState(nextState);
      refreshStatus(nextState.visible);
    }

    showButton.addEventListener("click", function () {
      var nextState = buildState(true);
      currentState = nextState;
      publishState(nextState);
      refreshStatus(true);
    });

    hideButton.addEventListener("click", function () {
      var nextState = buildState(false);
      currentState = nextState;
      publishState(nextState);
      refreshStatus(false);
    });

    nameInput.addEventListener("input", syncWhileVisible);
    categorySelect.addEventListener("change", syncWhileVisible);

    window.addEventListener("storage", function (event) {
      if (event.key !== STORAGE_KEY || !event.newValue) {
        return;
      }
      try {
        var state = JSON.parse(event.newValue);
        currentState = state;
        refreshStatus(Boolean(state.visible));
      } catch (error) {
        // Ignore invalid payloads from other tabs.
      }
    });
  }

  function initOverlayPage() {
    var lowerThird = document.getElementById("lowerThird");
    var nameEl = document.getElementById("participantName");
    var categoryEl = document.getElementById("participantCategory");

    if (!lowerThird || !nameEl || !categoryEl) {
      return;
    }

    var lastStamp = 0;

    function applyState(state) {
      if (!state || typeof state !== "object") {
        return;
      }

      if (typeof state.updatedAt === "number" && state.updatedAt < lastStamp) {
        return;
      }

      lastStamp = typeof state.updatedAt === "number" ? state.updatedAt : Date.now();
      nameEl.textContent = state.name && state.name.trim() ? state.name : " ";
      categoryEl.textContent = state.category || " ";
      lowerThird.classList.toggle("is-visible", Boolean(state.visible));
    }

    applyState(safeReadState());

    if (channel) {
      channel.onmessage = function (event) {
        applyState(event.data);
      };
    }

    window.addEventListener("storage", function (event) {
      if (event.key !== STORAGE_KEY || !event.newValue) {
        return;
      }
      try {
        applyState(JSON.parse(event.newValue));
      } catch (error) {
        // Ignore malformed state.
      }
    });

    // Polling is a local-file fallback when storage events are inconsistent between runtimes.
    setInterval(function () {
      applyState(safeReadState());
    }, 250);
  }

  var pageRole = document.body.getAttribute("data-page");

  if (pageRole === "control") {
    initControlPage();
  }

  if (pageRole === "overlay") {
    initOverlayPage();
  }
})();